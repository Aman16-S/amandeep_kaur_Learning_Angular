import java.util.Random;
import java.util.Scanner;

public class Hangman {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random ran = new Random();

        // Word sets for different topics
        String[][] wordSets = {
                {"Spring", "Summer", "Autumn", "Winter"},
                {"Canada", "Japan", "Brazil", "Australia", "Germany"},
                {"Red", "Blue", "Green", "Yellow", "Purple"}
        };

        boolean playAgain = true;

        while (playAgain) {
            // Display menu for topic selection
            System.out.println("\nWelcome to Hangman! Select a topic:");
            System.out.println("1. Seasons");
            System.out.println("2. Countries");
            System.out.println("3. Colors");
            System.out.print("Enter your choice (1/2/3): ");
            int choice = scanner.nextInt();

            if (choice < 1 || choice > 3) {
                System.out.println("Invalid choice. Please select a valid topic.");
                continue;
            }

            // Select word set based on user's choice
            String[] words = wordSets[choice - 1];
            String targetWord = words[ran.nextInt(words.length)];
            char[] maskedWord = new char[targetWord.length()];
            for (int i = 0; i < maskedWord.length; i++) {
                maskedWord[i] = '*';
            }

            int incorrectGuesses = 0;
            boolean isWordGuessed = false;
            StringBuilder guessedChars = new StringBuilder();

            // Start the guessing game
            while (!isWordGuessed) {

                System.out.print("(Guess) Enter a letter in word " + new String(maskedWord) + " > ");
                char guess = scanner.next().charAt(0);

                if (guessedChars.toString().contains(String.valueOf(guess))) {
                    System.out.println(guess + " has already been guessed.");
                    continue;
                }
                guessedChars.append(guess);

                boolean isCorrectGuess = false;
                for (int i = 0; i < targetWord.length(); i++) {
                    if (targetWord.charAt(i) == guess) {
                        maskedWord[i] = guess;
                        isCorrectGuess = true;
                    }
                }

                if (!isCorrectGuess) {
                    System.out.println(guess + " is not in the word.");
                    incorrectGuesses++;
                }


                if (new String(maskedWord).equals(targetWord)) {
                    isWordGuessed = true;
                    System.out.println("The word is " + targetWord + ". You missed " + incorrectGuesses + " time(s).");
                }
            }


            System.out.print("\nDo you want to guess another word? (y/n): ");
            char userChoice = scanner.next().toLowerCase().charAt(0);
            playAgain = (userChoice == 'y');
        }

        System.out.println("Thanks for playing!");
        scanner.close();
    }
}
