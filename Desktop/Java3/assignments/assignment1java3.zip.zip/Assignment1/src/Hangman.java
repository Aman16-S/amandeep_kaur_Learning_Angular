import java.util.Random;
import java.util.Scanner;

public class Hangman {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random ran = new Random();

        String[] words = {"Book", "Bag", "Pan", "Table", "Chair", "Program"};
        boolean playAgain = true;

        while (playAgain) {
            // Select a random word
            String targetWord = words[ran.nextInt(words.length)];
            char[] maskedWord = new char[targetWord.length()];
            for (int i = 0; i < maskedWord.length; i++) {
                maskedWord[i] = '*';
            }

            int incorrectGuesses = 0;
            boolean isWordGuessed = false;
            StringBuilder guessedChars = new StringBuilder();

            while (!isWordGuessed) {
                // Display masked word as a string
                System.out.print("(Guess) Enter a letter in word " + new String(maskedWord) + " > ");
                char guess = scanner.next().charAt(0);

                // Check if letter was already guessed
                if (guessedChars.toString().contains(String.valueOf(guess))) {
                    System.out.println(guess + " is already in the word.");
                    continue;
                }

                guessedChars.append(guess); // Add letter to guessed history

                boolean isCorrectGuess = false;
                for (int i = 0; i < targetWord.length(); i++) {
                    if (targetWord.charAt(i) == guess) {
                        maskedWord[i] = guess;
                        isCorrectGuess = true;
                    }
                }

                if (!isCorrectGuess) {
                    System.out.println(guess + " is not in the word.");
                    ++incorrectGuesses;
                }

                // Check if word is fully guessed
                if (new String(maskedWord).equals(targetWord)) {
                    isWordGuessed = true;
                    System.out.println("The word is " + targetWord + ". You missed " + incorrectGuesses + " times.");
                }
            }

            // Ask if the user wants to play again
            System.out.print("Do you want to guess another word? Enter y or n> ");
            char userChoice = scanner.next().toLowerCase().charAt(0);
            playAgain = (userChoice == 'y');
        }

        System.out.println("Thanks for playing!");
        scanner.close();
    }
}
